N_h=100;
N_l=60;
b=1;
c=1;
lambda=0.1;
alpha=0.6;
beta=0.5;
Omega=[0:1:10];
Q_o=((1+lambda).*N_h-lambda.*N_l-b.*c)./(4)
Q_s=((1+lambda).*N_h-lambda.*N_l-b.*c)./(4)
Q_r=((1+lambda).*N_h-lambda.*N_l-b.*c+(alpha-b.*beta).*Omega)./(4);
Qo=25.75*ones(1,length(Omega));
plot(Omega,Qo,'b-o','linewidth',1)
hold on;
Qs=25.75*ones(1,length(Omega));
plot(Omega,Qs,'r - .','linewidth',1)
hold on;
plot(Omega,Q_r,'g-*','linewidth',1)
ylim ([25.7 26])
xlabel ('\Omega','FontSize',14)
ylabel ('Q','FontSize',14)
legend({'Q_o^*','Q_s^*','Q_r^*'},'Location','northwest','Orientation','horizontal','FontSize',12)
legend('boxoff')