N_h=100;
N_l=60;
b=1;
c=1;
lambda=0.1;
beta=0.5;
Omega=5;
alpha=[0.5:0.05:1];
p_o=((3-lambda).*N_h+lambda*N_l+b*c)./(4*b);
p_s=((3-lambda).*N_h+lambda*N_l+b*c)./(4*b);
p_r=((3-lambda).*N_h+lambda*N_l+b*c+(3*alpha+b*beta).*Omega)./(4*b);
po=74.25*ones(1,length(alpha));
plot(alpha,po,'b-o','linewidth',1)
hold on;
ps=74.25*ones(1,length(alpha));
plot(alpha,ps,'r - .','linewidth',1)
hold on;
plot(alpha,p_r,'g-*','linewidth',1)
xlabel ('\alpha','FontSize',14)
ylabel ('p','FontSize',14)
legend({'p_o^*','p_s^*','p_r^*'},'Location','northwest','Orientation','horizontal','FontSize',12)
legend('boxoff')