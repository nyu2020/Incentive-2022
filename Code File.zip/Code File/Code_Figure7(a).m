N_h=100;
N_l=60;
b=1;
c=1;
alpha=0.5;
beta=0.5;
Omega=5;
lambda=[0:0.1:1];
p_o=((3-lambda).*N_h+lambda*N_l+b*c)./(4*b);
p_s=((3-lambda).*N_h+lambda*N_l+b*c)./(4*b);
p_r=((3-lambda).*N_h+lambda*N_l+b*c+(3*alpha+b*beta).*Omega)./(4*b);
plot(lambda,p_o,'b-o','linewidth',1)
hold on;
plot(lambda,p_s,'r - .','linewidth',1)
hold on;
plot(lambda,p_r,'g-*','linewidth',1)
xlabel ('\lambda','FontSize',14)
ylabel ('p','FontSize',14)
legend({'p_o^*','p_s^*','p_r^*'},'Location','northeast','Orientation','horizontal','FontSize',12)
legend('boxoff')