N_h=80;
N_l=20;
c=1;
b=1;
beta=0.4;
alpha=0.7;
lambda=0.4;
Omega=[0:1:50];
CS=(((1-3*lambda).*N_h+3*lambda.*N_l-b.*c+b.*(alpha-beta).*Omega).^2)./32-(((1-3*lambda).*N_h+3*lambda.*N_l-b.*c).^2)./32;
plot(Omega,CS,'black')
xlabel ('\Omega','FontSize',14)
ylabel ('\Delta CS','FontSize',14)
