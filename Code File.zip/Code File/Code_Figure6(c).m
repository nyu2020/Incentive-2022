N_h=100;
N_l=60;
b=1;
c=1;
lambda=0.1;
alpha=0.5;
Omega=5;
beta=[0:0.05:0.5];
w_o=(N_h+lambda*(N_h-N_l)+2*Omega*b+b*c)./(2*b)
w_s=(N_h+lambda*(N_h-N_l)+2*Omega*b+b*c)./(2*b)
w_r=(N_h+alpha*Omega+lambda*(N_h-N_l)+b*(c+beta*Omega))./(2*b);
wo=57.5*ones(1,length(beta));
plot(beta,wo,'b-o','linewidth',1)
hold on;
ws=57.5*ones(1,length(beta));
plot(beta,ws,'r - .','linewidth',1)
hold on;
plot(beta,w_r,'g-*','linewidth',1)
ylim ([53 59])
xlabel ('\beta','FontSize',14)
ylabel ('w','FontSize',14)
legend({'w_o^*','w_s^*','w_r^*'},'Location','northwest','Orientation','horizontal','FontSize',12)
legend('boxoff')