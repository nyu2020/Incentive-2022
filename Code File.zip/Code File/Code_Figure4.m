N_h=20;
N_l=1;
c=1;
b=1;
lambda=0.1;
alpha=0.6;
beta=[0:0.05:0.4];
omega=(2*(8*alpha.*lambda.*(N_h-N_l)-(alpha-beta).*((1+lambda).*N_h-lambda.*N_l-b.*c)))./(b.*(alpha-beta).^2);
plot(beta,omega,'k','linewidth',1)
xlim ([0 0.4])
ylim ([0 250])
xlabel ('\beta','FontSize',14)
ylabel ('\Omega','FontSize',14)
text(0.32,30,'OQP','FontSize',14,'FontName','Times New Roman','FontWeight','bold')
text(0.15,125,'CRP','FontSize',14,'FontName','Times New Roman','FontWeight','bold')