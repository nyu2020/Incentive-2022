N_h=20;
N_l=1;
c=1;
b=1;
lambda=0.2;
beta=0.4;
alpha=[0.6:0.05:1];
omega=(2*((b.*beta-alpha).*((1+lambda).*N_h-lambda.*N_l-b.*c)+4*b.*lambda.*(N_h-N_l).*(1-beta)))./((alpha-b.*beta).^2);
plot(alpha,omega,'k','linewidth',1)
xlim ([0.6 1])
ylim ([0 250])
xlabel ('\alpha','FontSize',14)
ylabel ('\Omega','FontSize',14)
text(0.64,30,'SQP','FontSize',14,'FontName','Times New Roman','FontWeight','bold')
text(0.8,125,'CRP','FontSize',14,'FontName','Times New Roman','FontWeight','bold')