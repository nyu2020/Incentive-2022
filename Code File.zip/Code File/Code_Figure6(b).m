N_h=100;
N_l=60;
b=1;
c=1;
lambda=0.1;
beta=0.5;
Omega=5;
alpha=[0.5:0.05:1];
w_o=(N_h+lambda*(N_h-N_l)+2*Omega*b+b*c)./(2*b)
w_s=(N_h+lambda*(N_h-N_l)+2*Omega*b+b*c)./(2*b)
w_r=(N_h+alpha*Omega+lambda*(N_h-N_l)+b*(c+beta*Omega))./(2*b);
wo=57.5*ones(1,length(alpha));
plot(alpha,wo,'b-o','linewidth',1)
hold on;
ws=57.5*ones(1,length(alpha));
plot(alpha,ws,'r - .','linewidth',1)
hold on;
plot(alpha,w_r,'g-*','linewidth',1)
ylim ([55 59])
xlabel ('\alpha','FontSize',14)
ylabel ('w','FontSize',14)
legend({'w_o^*','w_s^*','w_r^*'},'Location','northwest','Orientation','horizontal','FontSize',12)
legend('boxoff')